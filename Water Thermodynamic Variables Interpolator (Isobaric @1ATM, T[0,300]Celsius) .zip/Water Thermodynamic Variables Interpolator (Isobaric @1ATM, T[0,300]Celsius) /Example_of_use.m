%Example use of fwaterdata

%One Temperature input
tic
Data = fwaterdata([200])
toc

%Two Temperature input
tic
Data = fwaterdata([20,90])
toc


