%This MATLAB function uses input file water.cgi.txt - ref. National
%Institute of Standards and Technology [NIST], 2020
%(https://webbook.nist.gov/chemistry/fluid/).
 
%The function uses NIST Data to interpolate Thermodynamic Variables at an
%inputted temperature - Either single Temp value or Temperature Vector. If
%a Temperature Vector (i.e. [T1, T2]) is inputted, the function will find
%the thermodynamic variables at T1 and T2 as well as the average value
%(actual average from an interpolated date, not a linear average) of the
%thermodynamic variable between the two temperatures.
 
%INPUT = Temparature [Celcius] - Either T or [T1,T2] OUTPUT = Table of
%Thermodynamic Variables [TemperatureC Pressureatm Densitykgm3  Volumem3kg
%Internal EnergykJkg EnthalpykJk EntropyJgK CvJgK CpJgK  Sound Spdms
%JouleThomsonFatm ViscosityPas ThermCondWmK] && A plot showing
%thermodynamic variables with Temperature, Labelled with the identified
%variables at specified temperatures.
 
%Created by Will MacDonell (https://github.com/Will-MacDonell)

function [j]=fwaterdata(T)
lt=length(T);
if lt==1
format short g
fluid=readtable('water.cgi.txt');
figure('units','normalized','outerposition',[0 0 1 1])
warn=0
for i=1:11
    [Names]=fluid.Properties.VariableNames;
    X=fluid{:,1};
    Y=fluid{:,(i+2)};
    subplot(3,4,i)
    plot(X,Y,'m')
    hold on
    xlabel('Temperature, Celsius')
    ylabel(Names(i+2))
    p=interp1(Y,T);
    plot(T,p,'*')
    g=['is equal to ' num2str(p)];
    text(T+5,p,g,'rotation',10,'color','r')
    hold on
    b(:,i)=p';
end
    j=table(Names(3:13)',b','VariableNames',{'Variable' 'Value_for_T'});
    Prantl_Number=round((1000*b(7)*b(10))/b(11),2)
    
    
else if lt==2
  format short g
  if T(1)<100 && T(2)>100
      warn=1;
  end
fluid=readtable('water.cgi.txt');
figure('units','normalized','outerposition',[0 0 1 1])
for i=1:11
    [Names]=fluid.Properties.VariableNames;
    X=fluid{:,1};
    Y=fluid{:,(i+2)};
    subplot(3,4,i)
    plot(X,Y)
    hold on
    xlabel('Temperature, Celsius')
    ylabel(Names(i+2))
    Tstart=T(1);
    Tend=T(2);
    TT=[Tstart:0.1:Tend];
    lTT=length(TT);
    for h=1:lTT  
    p(h)=interp1(Y,TT(h));
    end
    
    AV=mean(p);
    [AV2 place]=min(abs(p-AV));
    plot(TT,p,'k-.',TT(place),AV,'*r')
    g=['Av is equal to ' num2str(AV)];
    text(TT(place)+5,AV,g,'rotation',10,'color','r');
    hold on
    b(i)=AV;
    
    for i=1:11
    [Names]=fluid.Properties.VariableNames;
    X=fluid{:,1};
    Y=fluid{:,(i+2)};
    subplot(3,4,i)
    plot(X,Y,'m')
    hold on
    xlabel('Temperature, Celsius')
    ylabel(Names(i+2))
    for o=1:2
    p2(o)=interp1(Y,T(o));
    plot(T(o),p2(o),'*b')
    end
    f(i)=p2(1);
    f2(i)=p2(2);
    end
end
 j=table(Names(3:13)',b',f',f2','VariableNames',{'Variable' 'Av_Value_for_T' 'For_Tstart' 'For_Tend'});
    Prantl_Number=round((1000*b(7)*b(10))/b(11),2)
    else 
        fluid=readtable('water.cgi.txt');
        figure('units','normalized','outerposition',[0 0 1 1])
        b=zeros(11,lt);
         for i=1:11 
    [Names]=fluid.Properties.VariableNames;
    X=fluid{:,1};
    Y=fluid{:,(i+2)};
    subplot(3,4,i)
    plot(X,Y,'m')
    hold on
    xlabel('Temperature, Celsius')
    ylabel(Names(i+2))
    for o=1:lt
    p2(o)=interp1(Y,T(o));
    plot(T(o),p2(o),'*b')
    end
    b(i,:)=p2';
    
         end
     j=table(Names(3:13)',b);
   
    end
   if warn==1
       warning('Warning - Temperatures Cross Phase Change');
   end
end
